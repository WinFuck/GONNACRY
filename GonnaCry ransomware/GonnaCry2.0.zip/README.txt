Hello. I see you're here to test GonnaCry2.0 ...
OK, I'll explain the rules for not getting a blue screen of death.

Here are the programs that cannot be started:
- control,

- sethc,

- adwcleaner_8.4.0,

- ProcessHacker,

- chrome,

- opera,

- msedge,

- avpui,

- AvastUI,

- resmon,

- processhacker-2.39-setup,

- regedit,

- cmd.
Do not run the above programs, lest you get a blue screen.
Write to the author for the decryption key.