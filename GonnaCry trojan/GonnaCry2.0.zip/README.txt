pass: 777e148e-86d7-46c2-b049-79a63f1cdf02
=======================================
ATTENTION! THIS FILE IS VERY DANGEROUS,
IF YOU DO NOT WANT YOUR DEVICE TO DAMAGE, 
DO NOT RUN THIS PROGRAM. 
YOU CAN RUN THIS PROGRAM IF YOU ARE AN ANTI-VIRUS TESTER. 
NEVER RUN THIS PROGRAM ON A REAL COMPUTER.

THIS FILE IS CORRUPTING WINDOWS REGISTRY ENTRIES,
AND REMOVES YOUR USER FROM YOUR COMPUTER.

Tested by: 2007user
=======================================
Language: C#
Malware type: Trojan horse
Supported Windows version:

Windows 7, Windows 8.x (Ends support at January 10, 2023), Windows 10, Windows 11
Tested on: Windows 10 21H2, Windows 10 20H2 Debloated.

DOESNT WORK ON: WINDOWS VISTA, WINDOWS XP.